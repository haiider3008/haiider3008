# Gramática en FNC y algoritmo CYK #



***Diagrama***

![diagramageneral](https://user-images.githubusercontent.com/17281733/33591171-e1826450-d951-11e7-9d67-a58064957dde.PNG)

***Video***
[![captura de pantalla 2018-07-13 a la s 3 14 16 p m](https://user-images.githubusercontent.com/17281733/42711956-6ef7b104-86af-11e8-95c0-c985740e24c6.png)](https://www.youtube.com/watch?v=UjZrYzHZFxo)
